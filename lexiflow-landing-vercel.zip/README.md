# LexiFlow Landing (Vercel-ready)

זהו פרויקט סטטי של עמוד נחיתה (ללא סליידר) מוכן לפריסה ב-Vercel דרך GitHub.

## שימוש
1) העלו את הקבצים לריפו ב-GitHub (קבצים: `index.html`, `vercel.json`).
2) ב-Vercel לחצו: New Project → בחרו את הריפו → Deploy.
3) אם תרצו לשנות את כתובת ההתחברות ל-Base44 ערכו ב-`index.html` את:
   `const LOGIN_URL = "https://lexi-flow-crm-088a2644.base44.app/login";`
