# LexiFlow Landing (static)

קובץ יחיד של עמוד נחיתה ללא סליידר.
* ערוך את כתובת ההתחברות ב-index.html בשורה `const LOGIN_URL = "https://lexi-flow-crm-088a2644.base44.app/login"` אם צריך.
* העלאה ל-Vercel: https://vercel.com/new (Deploy without Git) וגררו את התיקייה או את הקובץ index.html.
